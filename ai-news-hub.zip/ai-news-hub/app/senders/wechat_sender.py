import os
import requests


WEBHOOK = os.getenv("WECHAT_WEBHOOK")


def send_wechat(msg):

    data = {
        "msgtype": "markdown",
        "markdown": {"content": msg},
    }

    requests.post(WEBHOOK, json=data)